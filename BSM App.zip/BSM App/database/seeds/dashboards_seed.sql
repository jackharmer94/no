-- seeds/dashboards_seed.sql

INSERT INTO dashboards (name, type) VALUES ('Admin Dashboard 1', 'admin'), ('Admin Dashboard 2', 'admin'), ('Client Dashboard 1', 'client'), ('Client Dashboard 2', 'client');

-- seeds/users_seed.sql

INSERT INTO users (username, email, password) VALUES ('user1', 'user1@example.com', 'password1'), ('user2', 'user2@example.com', 'password2'), ('user3', 'user3@example.com', 'password3');

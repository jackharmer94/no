-- seeds/notifications_seed.sql

INSERT INTO notifications (message, type, target_users) VALUES ('Notification 1', 'manual', 'user1,user2'), ('Notification 2', 'automated', 'user3'), ('Notification 3', 'manual', 'user1');

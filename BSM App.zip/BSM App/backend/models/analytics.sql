CREATE TABLE analytics (
    id INT AUTO_INCREMENT PRIMARY KEY,
    // Define columns for analytics data
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
